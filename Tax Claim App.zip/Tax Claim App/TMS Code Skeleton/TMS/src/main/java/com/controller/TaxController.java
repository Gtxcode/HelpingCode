package com.controller;

import org.springframework.validation.BindingResult;

import com.model.UserClaim;

public class TaxController {
	
	
	
	public String calculateTax(UserClaim userClaim, BindingResult result) {
		return null;
	}

}
