package com.service;

import org.springframework.stereotype.Service;

import com.model.UserClaim;

@Service
public class TaxServiceImpl implements TaxService {

	// this method will calculate the tax claim based on the expense type and
	// expense amount
	@Override
	public double calculateTax(UserClaim userClaim) {
		double taxClaimAmt = 0.0;
		if (userClaim.getExpenseType().equals("MedicalExpense")) {
			if (userClaim.getExpenseAmt() <= 1000) {
				taxClaimAmt = userClaim.getExpenseAmt() * (.15);
			} else if (userClaim.getExpenseAmt() > 1000 && userClaim.getExpenseAmt() <= 10000) {
				taxClaimAmt = userClaim.getExpenseAmt() * (.20);
			} else {
				taxClaimAmt = userClaim.getExpenseAmt() * (.25);
			}
		} else if (userClaim.getExpenseType().equals("TravelExpense")) {
			if (userClaim.getExpenseAmt() <= 1000) {
				taxClaimAmt = userClaim.getExpenseAmt() * (.10);
			} else if (userClaim.getExpenseAmt() > 1000 && userClaim.getExpenseAmt() <= 10000) {
				taxClaimAmt = userClaim.getExpenseAmt() * (.15);
			} else {
				taxClaimAmt = userClaim.getExpenseAmt() * (.20);
			}
		} else {
			if (userClaim.getExpenseAmt() <= 1000) {
				taxClaimAmt = userClaim.getExpenseAmt() * (.05);
			} else if (userClaim.getExpenseAmt() > 1000 && userClaim.getExpenseAmt() <= 10000) {
				taxClaimAmt = userClaim.getExpenseAmt() * (.10);
			} else {
				taxClaimAmt = userClaim.getExpenseAmt() * (.15);
			}
		}
		return taxClaimAmt;
	}

}
