package com.controller;

import java.util.ArrayList;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.UserClaim;
import com.service.TaxService;

@Controller
public class TaxController {
	@Autowired
	TaxService taxService;

	@Autowired
	Validator validator;

	// this method will initially take user to the home page i.e
	// /getTaxClaimFormPage
	@RequestMapping(value = "/getTaxClaimFormPage", method = RequestMethod.GET)
	public String claimPage(@ModelAttribute("userClaim") UserClaim userClaim) {
		userClaim = new UserClaim();
		return "taxclaim";
	}

	// this method will take the user to the calculateTax page after calculating
	// tax claim amount
	@RequestMapping(value = "/calculateTax", method = RequestMethod.GET)
	public String calculateTax(@ModelAttribute("userClaim") @Valid UserClaim userClaim, BindingResult bindingResult,
			ModelMap map) {
		//validator.validate(userClaim, bindingResult);
		String res = "";
		if (bindingResult.hasErrors()) {
			res = "taxclaim";
		} else {
			double result = taxService.calculateTax(userClaim);
			map.addAttribute("taxClaimAmount", result);
			res = "result";
		}
		return res;
	}

	// this method will populate the expenseList into the drop down menu
	@ModelAttribute("expenseList")
	public List<String> populateExpense() {
		List<String> expenseList = new ArrayList<String>();
		expenseList.add("MedicalExpense");
		expenseList.add("TravelExpense");
		expenseList.add("FoodExpense");
		return expenseList;
	}

}
